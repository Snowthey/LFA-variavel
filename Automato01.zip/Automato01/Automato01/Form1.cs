﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Automato01
{
    public partial class Form1 : Form
    {
        string stringEntrada = string.Empty;
        public int quantidadeCaracteresEntrada;
        public char[] charEntrada;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            stringEntrada = textBoxEntrada.Text;

            quantidadeCaracteresEntrada = stringEntrada.Length;

            charEntrada = stringEntrada.ToCharArray();

            listBoxLog.Items.Clear();

            listBoxLog.Items.Add("*** Fita = " + stringEntrada);

            textBoxEntrada.Text = "";

            AutomatoFinitoDeterministico automato = new AutomatoFinitoDeterministico();

            bool resultado = automato.Reconhecer(stringEntrada, listBoxLog);

            if(resultado == true)
            {
                labelResposta.Text = "Variável";
            }
            else
            {
                labelResposta.Text = "Não é variavel";
            }
        }

        private void labelResposta_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
