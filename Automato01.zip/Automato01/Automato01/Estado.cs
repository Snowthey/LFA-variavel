﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Automato01
{
    internal class Estado
    {
        private bool EstadoFinal;

        Dictionary<char, string> Transicoes;

        public Estado(bool tipoEstado)
        {
            this.EstadoFinal = tipoEstado;

            Transicoes = new Dictionary<char, string>();
        }

        public bool EhEstadoFinal()
        {
            return EstadoFinal;
        }

        public void AdicionarTransicao(char SimboloLido, string EstadoTransicao)
        {
            Transicoes.Add(SimboloLido, EstadoTransicao);
        }

        public string RetornarNovoEstadoTransicao(char SimboloLido)
        {
            if (Transicoes.ContainsKey(SimboloLido))
            {
                return Transicoes[SimboloLido];
            }
            else return null;
        }
    }
}
