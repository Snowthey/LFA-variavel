﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Automato01
{
    internal class AutomatoFinitoDeterministico
    {
        private Dictionary<string, Estado> TabelaDeTransicao;

        public AutomatoFinitoDeterministico()
        {
            TabelaDeTransicao = new Dictionary<string, Estado>();

            Estado q0 = new Estado(false);
            q0.AdicionarTransicao('_', "q1");
            q0.AdicionarTransicao('a', "q2");
            q0.AdicionarTransicao('b', "q2");
            q0.AdicionarTransicao('c', "q2");
            q0.AdicionarTransicao('d', "q2");
            q0.AdicionarTransicao('e', "q2");
            q0.AdicionarTransicao('f', "q2");
            q0.AdicionarTransicao('g', "q2");
            q0.AdicionarTransicao('h', "q2");
            q0.AdicionarTransicao('i', "q2");
            q0.AdicionarTransicao('j', "q2");
            q0.AdicionarTransicao('k', "q2");
            q0.AdicionarTransicao('l', "q2");
            q0.AdicionarTransicao('m', "q2");
            q0.AdicionarTransicao('n', "q2");
            q0.AdicionarTransicao('o', "q2");
            q0.AdicionarTransicao('p', "q2");
            q0.AdicionarTransicao('q', "q2");
            q0.AdicionarTransicao('r', "q2");
            q0.AdicionarTransicao('s', "q2");
            q0.AdicionarTransicao('t', "q2");
            q0.AdicionarTransicao('u', "q2");
            q0.AdicionarTransicao('v', "q2");
            q0.AdicionarTransicao('w', "q2");
            q0.AdicionarTransicao('x', "q2");
            q0.AdicionarTransicao('y', "q2");
            q0.AdicionarTransicao('z', "q2");
            TabelaDeTransicao.Add("q0", q0);

            Estado q1 = new Estado(true);
            q1.AdicionarTransicao('_', "q1");
            q1.AdicionarTransicao('a', "q1");
            q1.AdicionarTransicao('b', "q1");
            q1.AdicionarTransicao('c', "q1");
            q1.AdicionarTransicao('d', "q1");
            q1.AdicionarTransicao('e', "q1");
            q1.AdicionarTransicao('f', "q1");
            q1.AdicionarTransicao('g', "q1");
            q1.AdicionarTransicao('h', "q1");
            q1.AdicionarTransicao('i', "q1");
            q1.AdicionarTransicao('j', "q1");
            q1.AdicionarTransicao('k', "q1");
            q1.AdicionarTransicao('l', "q1");
            q1.AdicionarTransicao('m', "q1");
            q1.AdicionarTransicao('n', "q1");
            q1.AdicionarTransicao('o', "q1");
            q1.AdicionarTransicao('p', "q1");
            q1.AdicionarTransicao('q', "q1");
            q1.AdicionarTransicao('r', "q1");
            q1.AdicionarTransicao('s', "q1");
            q1.AdicionarTransicao('t', "q1");
            q1.AdicionarTransicao('u', "q1");
            q1.AdicionarTransicao('v', "q1");
            q1.AdicionarTransicao('w', "q1");
            q1.AdicionarTransicao('x', "q1");
            q1.AdicionarTransicao('y', "q1");
            q1.AdicionarTransicao('0', "q1");
            q1.AdicionarTransicao('1', "q1");
            q1.AdicionarTransicao('2', "q1");
            q1.AdicionarTransicao('3', "q1");
            q1.AdicionarTransicao('4', "q1");
            q1.AdicionarTransicao('5', "q1");
            q1.AdicionarTransicao('6', "q1");
            q1.AdicionarTransicao('7', "q1");
            q1.AdicionarTransicao('8', "q1");
            q1.AdicionarTransicao('9', "q1");
            TabelaDeTransicao.Add("q1", q1);

            Estado q2 = new Estado(true);
            q2.AdicionarTransicao('_', "q2");
            q2.AdicionarTransicao('a', "q2");
            q2.AdicionarTransicao('b', "q2");
            q2.AdicionarTransicao('c', "q2");
            q2.AdicionarTransicao('d', "q2");
            q2.AdicionarTransicao('e', "q2");
            q2.AdicionarTransicao('f', "q2");
            q2.AdicionarTransicao('g', "q2");
            q2.AdicionarTransicao('h', "q2");
            q2.AdicionarTransicao('i', "q2");
            q2.AdicionarTransicao('j', "q2");
            q2.AdicionarTransicao('k', "q2");
            q2.AdicionarTransicao('l', "q2");
            q2.AdicionarTransicao('m', "q2");
            q2.AdicionarTransicao('n', "q2");
            q2.AdicionarTransicao('o', "q2");
            q2.AdicionarTransicao('p', "q2");
            q2.AdicionarTransicao('q', "q2");
            q2.AdicionarTransicao('r', "q2");
            q2.AdicionarTransicao('s', "q2");
            q2.AdicionarTransicao('t', "q2");
            q2.AdicionarTransicao('u', "q2");
            q2.AdicionarTransicao('v', "q2");
            q2.AdicionarTransicao('w', "q2");
            q2.AdicionarTransicao('x', "q2");
            q2.AdicionarTransicao('y', "q2");
            q2.AdicionarTransicao('0', "q2");
            q2.AdicionarTransicao('1', "q2");
            q2.AdicionarTransicao('2', "q2");
            q2.AdicionarTransicao('3', "q2");
            q2.AdicionarTransicao('4', "q2");
            q2.AdicionarTransicao('5', "q2");
            q2.AdicionarTransicao('6', "q2");
            q2.AdicionarTransicao('7', "q2");
            q2.AdicionarTransicao('8', "q2");
            q2.AdicionarTransicao('9', "q2");
            TabelaDeTransicao.Add("q2", q2);

        }

        public bool Reconhecer(String palavra, ListBox log)
        {
            string EstadoAual = "q0";

            int TamanhoPalavra = palavra.Length;

            char[] charEntrada = palavra.ToCharArray();

            for (int indice = 0; indice < TamanhoPalavra; indice++)
            {
                string textolog;
                textolog = "Estado atual = " + EstadoAual + "-- Simbolo lido = " + charEntrada[indice];

                EstadoAual = TabelaDeTransicao[EstadoAual].RetornarNovoEstadoTransicao(charEntrada[indice]);

                    if (EstadoAual == null)
                    {
                    textolog += "--> NÃO VAI PARA NENHUM ESTADO";
                    log.Items.Add(textolog);
                    return false;
                    }

                textolog += "--> vai para " + EstadoAual;
                log.Items.Add(textolog);
            }

            if (TabelaDeTransicao[EstadoAual].EhEstadoFinal())
            {
                log.Items.Add("ESTADO FINAL");
                return true;
            }
            else
            {
                log.Items.Add("NÃO É ESTADO FINAL!");
                return false;
            }

        }
    }
}
